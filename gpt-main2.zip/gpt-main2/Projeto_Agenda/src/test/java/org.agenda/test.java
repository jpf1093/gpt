package org.agenda;

import org.agenda.model.Contato;
import org.agenda.service.AgendaService;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AgendaServiceTest {

    @Test
    void testaAdicionarContato() {
        AgendaService agenda = new AgendaService();

        boolean resultado = agenda.adicionar(
                "João",
                "999999999",
                "joao@email.com",
                LocalDate.of(2000, 1, 1)
        );

        assertTrue(resultado);
        assertEquals(1, agenda.listar().size());
    }

    @Test
    void testaNaoAdicionarEmailDuplicado() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("João", "999", "email@test.com", LocalDate.of(2000, 1, 1));

        // Execução
        boolean resultado = agenda.adicionar("Maria", "888", "email@test.com", LocalDate.of(1999, 2, 2));

        // Verificação
        assertFalse(resultado);
        assertEquals(1, agenda.listar().size());
    }

    @Test
    void testaListarOrdenadoPorNome() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("Carlos", "111", "c@test.com", LocalDate.of(2000, 1, 1));
        agenda.adicionar("Ana", "222", "a@test.com", LocalDate.of(2000, 1, 1));

        List<Contato> lista = agenda.listar();

        assertEquals("Ana", lista.get(0).getNome());
        assertEquals("Carlos", lista.get(1).getNome());
    }

    @Test
    void testaRemoverContato() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("João", "999", "j@test.com", LocalDate.of(2000, 1, 1));

        boolean removido = agenda.remover(1);

        assertTrue(removido);
        assertEquals(0, agenda.listar().size());
    }

    @Test
    void testaEditarContato() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("João", "999", "j@test.com", LocalDate.of(2000, 1, 1));

        boolean editado = agenda.editar(
                1,
                "João Silva",
                "888",
                "novo@test.com",
                LocalDate.of(1995, 5, 5)
        );

        Contato c = agenda.buscarPorId(1);

        assertTrue(editado);
        assertEquals("João Silva", c.getNome());
        assertEquals("888", c.getTelefone());
    }

    @Test
    void testaPesquisarPorPrefixo() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("Ana", "111", "a@test.com", LocalDate.of(2000, 1, 1));
        agenda.adicionar("Carlos", "222", "c@test.com", LocalDate.of(2000, 1, 1));

        List<Contato> resultado = agenda.pesquisarPorPrefixo("An");

        assertEquals(1, resultado.size());
        assertEquals("Ana", resultado.get(0).getNome());
    }

    @Test
    void testaPesquisarPorTelefone() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("Ana", "12345", "a@test.com", LocalDate.of(2000, 1, 1));

        List<Contato> resultado = agenda.pesquisarPorTelefone("123");

        assertEquals(1, resultado.size());
    }

    @Test
    void testaAniversariantesDoMes() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("Ana", "111", "a@test.com", LocalDate.of(2000, 5, 10));
        agenda.adicionar("Carlos", "222", "c@test.com", LocalDate.of(2000, 6, 10));

        List<Contato> resultado = agenda.aniversariantesDoMes(5);

        assertEquals(1, resultado.size());
        assertEquals("Ana", resultado.get(0).getNome());
    }

    @Test
    void testaBuscarPorId() {
        AgendaService agenda = new AgendaService();

        agenda.adicionar("Ana", "111", "a@test.com", LocalDate.of(2000, 1, 1));

        Contato c = agenda.buscarPorId(1);

        assertNotNull(c);
        assertEquals("Ana", c.getNome());
    }

    @Test
    void testaBuscarPorIdInexistente() {
        AgendaService agenda = new AgendaService();

        Contato c = agenda.buscarPorId(99);

        assertNull(c);
    }
}