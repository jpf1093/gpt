package com.example.votos.repository;

import com.example.votos.model.Funcionario;
import com.example.votos.model.Voto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface VotoRepository extends JpaRepository<Voto, Long> {

    boolean existsByFuncionarioAndData(Funcionario funcionario, LocalDate data);

    @Query("""
        SELECT v.restaurante.nome, COUNT(v)
        FROM Voto v
        GROUP BY v.restaurante.nome
        ORDER BY COUNT(v) DESC
    """)
    List<Object[]> apuracao();
}