package com.example.votos.service;

import com.example.votos.model.*;
import com.example.votos.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

/**
 * Serviço responsável pelas regras de votação.
 */
@Service
public class VotoService {

    private final FuncionarioRepository funcionarioRepo;
    private final RestauranteRepository restauranteRepo;
    private final VotoRepository votoRepo;

    public VotoService(FuncionarioRepository f,
                       RestauranteRepository r,
                       VotoRepository v) {
        this.funcionarioRepo = f;
        this.restauranteRepo = r;
        this.votoRepo = v;
    }

    public void votar(String nomeFuncionario, String nomeRestaurante) {

        nomeFuncionario = nomeFuncionario.trim().toLowerCase();
        nomeRestaurante = nomeRestaurante.trim().toLowerCase();

        Funcionario funcionario = funcionarioRepo
                .findByNome(nomeFuncionario)
                .orElse(new Funcionario(nomeFuncionario));

        if (funcionario.getId() != null &&
                votoRepo.existsByFuncionarioAndData(funcionario, LocalDate.now())) {
            throw new RuntimeException("Funcionário já votou hoje!");
        }

        Restaurante restaurante = restauranteRepo
                .findByNome(nomeRestaurante)
                .orElse(new Restaurante(nomeRestaurante));

        Voto voto = new Voto(funcionario, restaurante);

        votoRepo.save(voto);
    }

    public java.util.List<Object[]> apurar() {
        return votoRepo.apuracao();
    }
}