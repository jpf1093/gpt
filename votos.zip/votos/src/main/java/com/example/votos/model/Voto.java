package com.example.votos.model;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * Entidade que representa um voto.
 */
@Entity
public class Voto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate data;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "funcionario_id", nullable = false)
    private Funcionario funcionario;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "restaurante_id", nullable = false)
    private Restaurante restaurante;

    public Voto() {}

    public Voto(Funcionario funcionario, Restaurante restaurante) {
        this.funcionario = funcionario;
        this.restaurante = restaurante;
        this.data = LocalDate.now();
    }

    public Long getId() { return id; }
    public LocalDate getData() { return data; }
    public Funcionario getFuncionario() { return funcionario; }
    public Restaurante getRestaurante() { return restaurante; }
}