package com.example.votos.controller;

import com.example.votos.service.VotoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class VotoController {

    private final VotoService service;

    public VotoController(VotoService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @PostMapping("/votar")
    public String votar(@RequestParam String funcionario,
                        @RequestParam String restaurante,
                        RedirectAttributes redirectAttributes) {

        try {
            service.votar(funcionario, restaurante);
            redirectAttributes.addFlashAttribute("mensagem", "Voto registrado com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }

        return "redirect:/";
    }

    @GetMapping("/apuracao")
    public String apuracao(Model model) {
        model.addAttribute("resultado", service.apurar());
        return "apuracao";
    }
}