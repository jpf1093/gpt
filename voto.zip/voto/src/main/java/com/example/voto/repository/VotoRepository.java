package com.example.voto.repository;

import com.example.voto.entity.Funcionario;
import com.example.voto.entity.Voto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface VotoRepository extends JpaRepository<Voto, Long> {

    boolean existsByFuncionarioAndData(Funcionario funcionario, LocalDate data);

    @Query("""
        SELECT r.nome, COUNT(v)
        FROM Voto v
        JOIN v.restaurante r
        GROUP BY r.nome
        ORDER BY COUNT(v) DESC
    """)
    List<Object[]> apuracao();
}