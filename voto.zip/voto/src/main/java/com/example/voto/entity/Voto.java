package com.example.voto.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "voto")
public class Voto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate data;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_funcionario")
    private Funcionario funcionario;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_restaurante")
    private Restaurante restaurante;

    public Voto() {
    }
    
//criacao do voto completo com data funcionario e restaurante
    public Voto(LocalDate data,
                Funcionario funcionario,
                Restaurante restaurante) {

        this.data = data;
        this.funcionario = funcionario;
        this.restaurante = restaurante;
    }

    public Long getId() {
        return id;
    }

    public LocalDate getData() {
        return data;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public Restaurante getRestaurante() {
        return restaurante;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public void setRestaurante(Restaurante restaurante) {
        this.restaurante = restaurante;
    }
}