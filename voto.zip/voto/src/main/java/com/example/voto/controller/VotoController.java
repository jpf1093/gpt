package com.example.voto.controller;

import com.example.voto.service.VotoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class VotoController {

    @Autowired
    private VotoService votoService;

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/votar")
    public String votar(
            @RequestParam String funcionario,
            @RequestParam String restaurante,
            RedirectAttributes redirectAttributes) {

        try {
            votoService.registrarVoto(funcionario, restaurante);
            redirectAttributes.addFlashAttribute("mensagem", "✅ Voto registrado com sucesso!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("erro", e.getMessage());
        }

        return "redirect:/";
    }

    @GetMapping("/apuracao")
    public String apuracao(Model model) {

        model.addAttribute("resultado", votoService.apuracao());

        return "apuracao";
    }
}