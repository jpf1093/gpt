package com.example.voto.repository;

import com.example.voto.entity.Restaurante;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RestauranteRepository
        extends JpaRepository<Restaurante, Long> {

    Optional<Restaurante> findByNome(String nome);
}