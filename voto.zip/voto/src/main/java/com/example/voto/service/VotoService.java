package com.example.voto.service;

import com.example.voto.entity.Funcionario;
import com.example.voto.entity.Restaurante;
import com.example.voto.entity.Voto;
import com.example.voto.repository.FuncionarioRepository;
import com.example.voto.repository.RestauranteRepository;
import com.example.voto.repository.VotoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class VotoService {

    private final VotoRepository votoRepository;
    private final FuncionarioRepository funcionarioRepository;
    private final RestauranteRepository restauranteRepository;

    public VotoService(
            VotoRepository votoRepository,
            FuncionarioRepository funcionarioRepository,
            RestauranteRepository restauranteRepository
    ) {
        this.votoRepository = votoRepository;
        this.funcionarioRepository = funcionarioRepository;
        this.restauranteRepository = restauranteRepository;
    }

    public void registrarVoto(String funcionarioNome, String restauranteNome) {

        final String funcionarioNormalizado = normalizar(funcionarioNome);
        final String restauranteNormalizado = normalizar(restauranteNome);

        Funcionario funcionario = funcionarioRepository
                .findByNome(funcionarioNormalizado)
                .orElseGet(() -> {
                    Funcionario novo = new Funcionario();
                    novo.setNome(funcionarioNormalizado);
                    return funcionarioRepository.save(novo);
                });

        Restaurante restaurante = restauranteRepository
                .findByNome(restauranteNormalizado)
                .orElseGet(() -> {
                    Restaurante novo = new Restaurante();
                    novo.setNome(restauranteNormalizado);
                    return restauranteRepository.save(novo);
                });

        if (votoRepository.existsByFuncionarioAndData(funcionario, LocalDate.now())) {
            throw new RuntimeException("Funcionário já votou hoje!");
        }

        Voto voto = new Voto();
        voto.setFuncionario(funcionario);
        voto.setRestaurante(restaurante);
        voto.setData(LocalDate.now());

        votoRepository.save(voto);
    }

    public List<Object[]> apuracao() {
        return votoRepository.apuracao();
    }

    //retorna texto normalizado (sem espaços e em minúsculo)
    private String normalizar(String texto) {
        return texto.trim().toLowerCase();
    }
}