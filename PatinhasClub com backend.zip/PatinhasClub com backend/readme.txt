./mvnw spring-boot:run


npm run dev


mariadeb  CREATE DATABASE login_db;