package com.backend.patinhasclub.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

  @GetMapping("/api/teste")
public String teste() {
    System.out.println("BATEU NO ENDPOINT");
    return "rota protegida funcionando";
}
}