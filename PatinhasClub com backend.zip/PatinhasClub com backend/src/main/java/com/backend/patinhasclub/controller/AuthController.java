package com.backend.patinhasclub.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.backend.patinhasclub.dto.request.LoginRequest;
import com.backend.patinhasclub.dto.request.RegisterRequest;
import com.backend.patinhasclub.dto.response.LoginResponse;
import com.backend.patinhasclub.dto.response.MessageResponse;
import com.backend.patinhasclub.service.AuthService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            String token = authService.login(
                    request.getUsername(),
                    request.getPassword()
            );

            return ResponseEntity.ok(
                    new LoginResponse("ok", token)
            );

        } catch (RuntimeException e) {
            return ResponseEntity
                    .status(401)
                    .body(new MessageResponse("error", e.getMessage()));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
        try {
            authService.register(request);

            return ResponseEntity.ok(
                    new MessageResponse("ok", "usuario criado com sucesso")
            );

        } catch (RuntimeException e) {
            return ResponseEntity
                    .status(400)
                    .body(new MessageResponse("error", e.getMessage()));
        }
    }
}