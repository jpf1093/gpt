package com.backend.patinhasclub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.patinhasclub.model.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    boolean existsByCpf(String cpf);
}