package com.backend.patinhasclub.dto.request;

public class RegisterRequest {

    private String username;
    private String password;
    private String email;
    private String telefone;
    private String cpf;
    private String nome;
    private String sobrenome;

    public RegisterRequest() {
    }

    public RegisterRequest(String username, String password, String email, String telefone, String cpf, String nome, String sobrenome) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.telefone = telefone;
        this.cpf = cpf;
        this.nome = nome;
        this.sobrenome = sobrenome;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }
}