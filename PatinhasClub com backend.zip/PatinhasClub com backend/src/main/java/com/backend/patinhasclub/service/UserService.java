package com.backend.patinhasclub.service;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.backend.patinhasclub.model.User;
import com.backend.patinhasclub.repository.UserRepository;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder encoder;

    public UserService(UserRepository userRepository, BCryptPasswordEncoder encoder) {
        this.userRepository = userRepository;
        this.encoder = encoder;
    }

    public String register(User user) {

        if (userRepository.existsByUsername(user.getUsername())) {
            return "USERNAME_JA_EXISTE";
        }

        if (userRepository.existsByEmail(user.getEmail())) {
            return "EMAIL_JA_EXISTE";
        }

        if (userRepository.existsByCpf(user.getCpf())) {
            return "CPF_JA_EXISTE";
        }

        user.setPassword(encoder.encode(user.getPassword()));
        userRepository.save(user);

        return "OK";
    }

    public Optional<User> login(String username, String password) {

        Optional<User> userOpt = userRepository.findByUsername(username);

        if (userOpt.isEmpty()) return Optional.empty();

        User user = userOpt.get();

        if (!encoder.matches(password, user.getPassword())) {
            return Optional.empty();
        }

        // remove senha antes de retornar
        user.setPassword(null);

        return Optional.of(user);
    }
}