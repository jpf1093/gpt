package com.backend.patinhasclub.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.*;

@org.springframework.context.annotation.Configuration
public class CorsConfig {

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(@org.springframework.lang.NonNull CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("http://localhost:5173")
                        .allowedMethods("*");
            }
        };
    }
} 
    

