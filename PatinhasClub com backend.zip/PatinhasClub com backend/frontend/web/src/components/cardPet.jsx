import '../global.css'
import { Link } from "react-router-dom"

export function Cards({ nome, imagem, especie, cor, genero, porte, idade }) {
    return (
        <Link to="">
            <div className={`perfil ${especie} ${cor} ${genero} ${porte} idade-${idade}`}>
                <img src={imagem} />
                <h3>{nome}</h3>
            </div>
        </Link>
    )
}