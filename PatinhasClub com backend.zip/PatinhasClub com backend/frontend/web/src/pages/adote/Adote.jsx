import { useState } from "react";
import { Cards } from '../../components/cardPet.jsx'
import exPets from '../../components/exPets.json'
import './adote.css'

export function AdoteGatos() {
    const [aberto, setAberto] = useState({
        pelagem: false,
        porte: false,
        idade: false
    });

    function toggle(secao) {
        setAberto(prev => ({
            ...prev,
            [secao]: !prev[secao]
        }));
    }

    const [filtros, setFiltros] = useState({
        pelagem: [],
        porte: [],
        idade: []
    });

    function handleFiltro(e) {
        const { name, checked, dataset } = e.target;
        const categoria = dataset.categoria;

        setFiltros(prev => {
            const lista = prev[categoria];

            return {
                ...prev,
                [categoria]: checked
                    ? [...lista, name]
                    : lista.filter(f => f !== name)
            };
        });
    }

    const petsFiltrados = exPets.filter(pet => {

        const matchPelagem =
            filtros.pelagem.length === 0 ||
            filtros.pelagem.some(f => pet.cor.includes(f));

        const matchPorte =
            filtros.porte.length === 0 ||
            filtros.porte.includes(pet.porte);

        const matchIdade =
            filtros.idade.length === 0 ||
            (
                (filtros.idade.includes("filhote") && pet.idade <= 1) ||
                (filtros.idade.includes("jovem") && pet.idade <= 3) ||
                (filtros.idade.includes("adulto") && pet.idade <= 7) ||
                (filtros.idade.includes("idoso") && pet.idade > 7)
            );

        return matchPelagem && matchPorte && matchIdade;
    });

    return (
        <div className="body_adote">
            <div className="seletor">

                <button onClick={() => toggle("pelagem")}>
                    {aberto.pelagem ? "Esconder" : "Pelagem"}
                </button>

                {aberto.pelagem && <div>
                    <label><input type="checkbox" name="branco" data-categoria="pelagem" onChange={handleFiltro} /> Branco</label>
                    <label><input type="checkbox" name="cinza" data-categoria="pelagem" onChange={handleFiltro} /> Cinza</label>
                    <label><input type="checkbox" name="escaminha" data-categoria="pelagem" onChange={handleFiltro} /> Escaminha</label>
                    <label><input type="checkbox" name="frajola" data-categoria="pelagem" onChange={handleFiltro} /> Frajola</label>
                    <label><input type="checkbox" name="laranja" data-categoria="pelagem" onChange={handleFiltro} /> Laranja</label>
                    <label><input type="checkbox" name="preto" data-categoria="pelagem" onChange={handleFiltro} /> Preto</label>
                    <label><input type="checkbox" name="siames" data-categoria="pelagem" onChange={handleFiltro} /> Siamês</label>
                    <label><input type="checkbox" name="tigrado" data-categoria="pelagem" onChange={handleFiltro} /> Tigrado</label>
                    <label><input type="checkbox" name="tricolor" data-categoria="pelagem" onChange={handleFiltro} /> Tricolor</label>
                </div>}

                <button onClick={() => toggle("porte")}>
                    {aberto.porte ? "Esconder" : "Porte"}
                </button>

                {aberto.porte && <div>
                    <label><input type="checkbox" name="grande" data-categoria="porte" onChange={handleFiltro} /> Grande</label>
                    <label><input type="checkbox" name="medio" data-categoria="porte" onChange={handleFiltro} /> Médio</label>
                    <label><input type="checkbox" name="pequeno" data-categoria="porte" onChange={handleFiltro} /> Pequeno</label>
                </div>}

                <button onClick={() => toggle("idade")}>
                    {aberto.idade ? "Esconder" : "Idade"}
                </button>

                {aberto.idade && <div>
                    <label><input type="checkbox" name="filhote" data-categoria="idade" onChange={handleFiltro} /> Filhote</label>
                    <label><input type="checkbox" name="jovem" data-categoria="idade" onChange={handleFiltro} /> Jovem</label>
                    <label><input type="checkbox" name="adulto" data-categoria="idade" onChange={handleFiltro} /> Adulto</label>
                    <label><input type="checkbox" name="idoso" data-categoria="idade" onChange={handleFiltro} /> Idoso</label>
                </div>}
            </div>

            <div className="ex_animais">
                {petsFiltrados.map((pet, index) => (
                    <Cards
                        key={index}
                        nome={pet.nome}
                        imagem={pet.imagem}
                        especie={pet.especie}
                        cor={pet.cor}
                        genero={pet.genero}
                        porte={pet.porte}
                        idade={pet.idade}
                    />
                ))}
            </div>
        </div>
    );
}