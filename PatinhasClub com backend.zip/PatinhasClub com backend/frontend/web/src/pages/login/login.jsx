import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./login.css";

export function Login() {
    const navigate = useNavigate(); 
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [nome, setNome] = useState("");
  const [sobrenome, setSobrenome] = useState("");
  const [email, setEmail] = useState("");
  const [telefone, setTelefone] = useState("");
  const [cpf, setCpf] = useState("");

  const [message, setMessage] = useState("");
  const [isRegister, setIsRegister] = useState(false);

 

  const handleSubmit = async (e) => {
    e.preventDefault();

    const url = isRegister
      ? "http://localhost:8080/api/register"
      : "http://localhost:8080/api/login";

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(
          isRegister
            ? {
                username,
                password,
                email,
                telefone,
                cpf,
                nome,
                sobrenome
              }
            : { username, password }
        )
      });

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || data.status || "Erro");
        return;
      }

      // LOGIN
      if (!isRegister) {
        localStorage.setItem("token", data.token);

        setMessage("Login realizado com sucesso 👌");

        setTimeout(() => {
          navigate("/");
        }, 500);

        return;
      }

      // REGISTER
      setMessage("Conta criada com sucesso!");
      setIsRegister(false);

      // limpa campos extras
      setNome("");
      setSobrenome("");
      setEmail("");
      setTelefone("");
      setCpf("");

    } catch (err) {
      console.error(err);
      setMessage("Erro ao conectar com servidor");
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1>{isRegister ? "Criar Conta" : "Login"}</h1>
        <p>{isRegister ? "Crie sua nova conta" : "Acesse sua conta"}</p>

        <form onSubmit={handleSubmit} className="input-group">

          <input
            className="login-input"
            placeholder="Nome de Usuário"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />

          <input
            className="login-input"
            placeholder="Senha"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          {isRegister && (
            <>
              <input
                className="login-input"
                placeholder="Nome"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                required
              />

              <input
                className="login-input"
                placeholder="Sobrenome"
                value={sobrenome}
                onChange={(e) => setSobrenome(e.target.value)}
                required
              />

              <input
                className="login-input"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />

              <input
                className="login-input"
                placeholder="Telefone"
                value={telefone}
                onChange={(e) => setTelefone(e.target.value)}
                required
              />

              <input
                className="login-input"
                placeholder="CPF"
                value={cpf}
                onChange={(e) => setCpf(e.target.value)}
                required
              />
            </>
          )}

          <button type="submit" className="login-button">
            {isRegister ? "Criar conta" : "Entrar"}
          </button>
        </form>

        {message && <p style={{ marginTop: 10 }}>{message}</p>}

        <p
          onClick={() => setIsRegister(!isRegister)}
          style={{
            marginTop: "15px",
            color: "#1877f2",
            cursor: "pointer",
            fontSize: "14px"
          }}
        >
          {isRegister
            ? "Já tem conta? Entrar"
            : "Não tem conta? Criar conta"}
        </p>
      </div>
    </div>
  );
}

