import { Cards } from '../../components/cardPet.jsx'
import { Link } from "react-router-dom"
import exPets from '../../components/exPets.json'
import './home.css'

export function Home() {
    return (
        <>
            <div className="body_home">
                <p>O projeto Patinhas: <br />
                    O Patinhas nasceu de uma simples ideia que surgiu enquanto um grupo de jovens programadores caminhava pelas ruas de Porto
                    Alegre e via tantos animais sem um lar. <br />

                    O projeto tem como objetivo alcançar o maior número possível de pessoas, mostrando quantos animais esperam por
                    uma chance de receber amor e facilitar o processo de adoção. <br />

                    A cada dia, o que começou como um sonho vai ganhando forma e se tornando realidade.</p>


                <Link to="/adote" id="btn_adote">Adotar</Link>

                <h2 id='title_animais'>Animais precisando de um lar:</h2>

                <div className="ex_animais">
                    <div className="track right">
                        {exPets.map((pet, index) => (
                            <Cards
                                key={index}
                                nome={pet.nome}
                                imagem={pet.imagem}
                                especie={pet.especie}
                                cor={pet.cor}
                                genero={pet.genero}
                                porte={pet.porte}
                                idade={pet.idade}
                            />
                        ))}
                        {exPets.map((pet, index) => (
                            <Cards
                                key={`dup-${index}`}
                                nome={pet.nome}
                                imagem={pet.imagem}
                                especie={pet.especie}
                                cor={pet.cor}
                                genero={pet.genero}
                                porte={pet.porte}
                                idade={pet.idade}
                            />
                        ))}
                    </div>

                </div>
            </div >

        </>
    )
}