import { BrowserRouter, Routes, Route } from "react-router-dom"
import { useState } from 'react'
import { Home } from "./pages/home/Home"
import { AdoteGatos } from "./pages/adote/Adote"
import { Header_padrao } from "./components/header_padrao"
import './global.css'
import { Login } from "./pages/login/login"


function App() {

  return (
    <>
      <BrowserRouter>

        <Header_padrao />

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/adote" element={<AdoteGatos />} />
          <Route path="/login" element={<Login/>}/>
        </Routes>
      </BrowserRouter>

    </>
  )
}

export default App
